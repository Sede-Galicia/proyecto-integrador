document.getElementById("crear").addEventListener("click", function() {
  let username = document.getElementById("name").value;
  let password = document.getElementById("password").value;
  let email = document.getElementById("email").value;

  alert("Usuario creado exitosamente"); 
});