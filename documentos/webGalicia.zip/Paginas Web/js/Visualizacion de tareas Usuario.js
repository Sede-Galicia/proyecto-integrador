function BuscarTarea() {
  let Buscar = document.getElementById('searchInput').value.toLowerCase();
  let filas = document.querySelectorAll('#task-table tr');

  for (let i = 1; i < filas.length; i++) {
    let fila = filas[i];
    let id = fila.cells[0].textContent.toLowerCase();
    let priorodad = fila.cells[2].textContent.toLowerCase();

    if (id.includes(Buscar) || priorodad.includes(Buscar)) {
      fila.style.display = '';
    } else {
      fila.style.display = 'none';
    }
  }
}


