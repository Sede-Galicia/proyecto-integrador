//Credenciales usuario root:
const SuperUsuario = 'Administrador';
const SuperUsuario_Passwd = 'Galicia@1234';

function Inicializar() {
    boton = document.getElementById("btnEnviar");
    boton.addEventListener('click', doProcesarForm(), false);
}
function doComprobacion(nombre , contra) {
    if (nombre != SuperUsuario || contra != SuperUsuario_Passwd){
        return false;
    }
    return true;
}
function doProcesarForm(){
    //Asignamos a las varibales nombres y passwd los input del html.
    let nombres = document.getElementById("input_nombre_usuario").value;
    let passwd = document.getElementById("input_passwd_usuario").value;
    if (doComprobacion(nombres , passwd)) {
        alert("¡Bienvenido, estás dentro!.");
        window.location.href = "indice.html";
    } 
    else {
        alert("ERROR: Usuario o contraseña incorrecta.");
    }
}
function mostrarContraseña() {
    let campoContraseña = document.getElementById("input_passwd_usuario");
    if (campoContraseña.type === "password") {
        campoContraseña.type = "text";
    } else {
        campoContraseña.type = "password";
    }
  }

window.addEventListener('load', Inicializar);