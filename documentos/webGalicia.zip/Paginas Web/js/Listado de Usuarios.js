function buscarUsuario() {
    let BuscarTexto = document.getElementById("search-input").value.toLowerCase();
    let TarjetaUsuarios = document.getElementsByClassName("user-card");

    for (let i = 0; i < TarjetaUsuarios.length; i++) {
        let TarjetaUsuario = TarjetaUsuarios[i];
        let DetallesUsuario = TarjetaUsuario.getElementsByClassName("user-details")[0];
        let NombreUsuario = DetallesUsuario.getElementsByTagName("h4")[0].innerText.toLowerCase();
        let RolUsuario = DetallesUsuario.getElementsByTagName("p")[0].innerText.toLowerCase();

        if (NombreUsuario.includes(BuscarTexto) || RolUsuario.includes(BuscarTexto)) {
            TarjetaUsuario.style.display = "block";
        } else {
            TarjetaUsuario.style.display = "none";
        }
    }
}

let searchInput = document.getElementById("search-input");
searchInput.addEventListener("keyup", buscarUsuario);