let TareaFormulario = document.getElementById("task-form");
TareaFormulario.addEventListener("submit", function (event) {
    event.preventDefault();


    let TituloTarea = document.getElementById("task-title").value;
    let DescripcionTarea = document.getElementById("task-description").value;
    let TiempoTarea = document.getElementById("task-time").value;
    let CreadorTarea = document.getElementById("task-creator").value;
    let AsignacionTarea = document.getElementById("task-assignee").value;


    let tarea = {
        Titulo: TituloTarea,
        Descripcion: DescripcionTarea,
        Tiempo: TiempoTarea,
        Creador: CreadorTarea,
        Asignado: AsignacionTarea
    };


    console.log(tarea);


    TareaFormulario.reset();
});
