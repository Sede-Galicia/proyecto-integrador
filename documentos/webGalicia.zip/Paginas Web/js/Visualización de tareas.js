function cambiarEstado(idTarea, estado) {
  const indiceTarea = tareas.findIndex(tarea => tarea.id === idTarea);
  if (indiceTarea !== -1) {
    tareas[indiceTarea].estado = estado;
    renderizarListaTareas();
  }
}

function agregarComentario(idTarea, comentario) {
  const indiceTarea = tareas.findIndex(tarea => tarea.id === idTarea);
  if (indiceTarea !== -1) {
    tareas[indiceTarea].comentarios.push(comentario);
    renderizarListaTareas();
  }
}

function renderizarListaTareas() {
  const listaTareas = document.getElementById('taskList');
  listaTareas.innerHTML = '';

  tareas.forEach(tarea => {
    const listItem = document.createElement('li');
    listItem.className = 'list-group-item';

    const nombreTarea = document.createElement('span');
    nombreTarea.innerText = tarea.nombre;

    const estadoBadge = document.createElement('span');
    estadoBadge.className = 'badge ' + (tarea.estado === 'completada' ? 'badge-success' : 'badge-warning');
    estadoBadge.innerText = tarea.estado;

    const botonEstado = document.createElement('button');
    botonEstado.className = 'btn btn-sm btn-outline-primary';
    botonEstado.innerText = 'Cambiar Estado';
    botonEstado.addEventListener('click', () => {
      const nuevoEstado = tarea.estado === 'pendiente' ? 'completada' : 'pendiente';
      cambiarEstado(tarea.id, nuevoEstado);
    });

    const listaComentarios = document.createElement('ul');
    listaComentarios.className = 'list-group mt-2';

    tarea.comentarios.forEach(comentario => {
      const comentarioItem = document.createElement('li');
      comentarioItem.className = 'list-group-item';
      comentarioItem.innerText = comentario;
      listaComentarios.appendChild(comentarioItem);
    });

    const formularioComentario = document.createElement('form');
    formularioComentario.addEventListener('submit', event => {
      event.preventDefault();
      const campoComentario = formularioComentario.querySelector('input');
      const comentario = campoComentario.value;
      agregarComentario(tarea.id, comentario);
      campoComentario.value = '';
    });

    const campoComentario = document.createElement('input');
    campoComentario.type = 'text';
    campoComentario.className = 'form-control form-control-sm';
    campoComentario.placeholder = 'Añadir un comentario...';

    const botonComentario = document.createElement('button');
    botonComentario.type = 'submit';
    botonComentario.className = 'btn btn-sm btn-outline-primary';
    botonComentario.innerText = 'Añadir';

    formularioComentario.appendChild(campoComentario);
    formularioComentario.appendChild(botonComentario);

    const taskDetails = document.createElement('div');
    taskDetails.className = 'task-details';
    taskDetails.appendChild(nombreTarea);
    taskDetails.appendChild(estadoBadge);
    taskDetails.appendChild(botonEstado);

    listItem.appendChild(taskDetails);
    listItem.appendChild(listaComentarios);
    listItem.appendChild(formularioComentario);

    listaTareas.appendChild(listItem);
  });
}

let tareas = [
  { id: 1, nombre: 'Tarea 1', estado: 'completada', comentarios: [] },
  { id: 2, nombre: 'Tarea 2', estado: 'pendiente', comentarios: [] },
  { id: 3, nombre: 'Tarea 3', estado: 'completada', comentarios: [] },
  { id: 4, nombre: 'Tarea 4', estado: 'pendiente', comentarios: [] },
  { id: 5, nombre: 'Tarea 5', estado: 'completada', comentarios: [] }
];


window.addEventListener('load', () => {
  renderizarListaTareas();
});


const formularioNuevaTarea = document.getElementById('newTaskForm');
formularioNuevaTarea.addEventListener('submit', event => {
  event.preventDefault();
  const campoNombreTarea = formularioNuevaTarea.querySelector('#taskName');
  const nombreTarea = campoNombreTarea.value;
  const nuevaTarea = { id: tareas.length + 1, nombre: nombreTarea, estado: 'pendiente', comentarios: [] };
  tareas.push(nuevaTarea);
  renderizarListaTareas();
  campoNombreTarea.value = '';
});